import java.util.*;
import bank1.bank;
class sample implements bank{
    String username,password;
    double balance;
    sample(String username,String password,double balance)
    {
        this.username=username;
        this.password=password;
        this.balance=balance;
    }
    sample(){}
    public int checkcreadentials(String name,String pass)
    {
        if(username.equals(name) && password.equals(pass))
        {
            System.out.println("Authentication Succeed\n");
            return 1;
        }
        return 0;
    }
    public void deposit(double amount)
    {
        balance+=amount;
    }
    public void withdraw(double amount)
    {
        if(balance>amount)
        {
            balance-=amount;
        }
        else
        {
            System.out.println("insuffient money to withdraw");
        }
    }
    public void checkbalance()
    {
        System.out.println("your balance ="+balance);
    }
    public void exit()
    {
        System.exit(0);
    }

}
public class ATM {

    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);    
        int k,f=0;
        sample[] s=new sample[10];
        s[0]=new sample("topperworld","12345",100000);
        s[1]=new sample("webdevelopment","12345",20000);
        s[2]=new sample("intern","12345",300000);
        do{
            System.out.println("do you want to perform ani actions on your account:\n");
            System.out.println("enter 1 for yes 0 for no\n");
            k=in.nextInt();
            int i;
            if(k==1)
            {
                System.out.println("enter your username");
                String name=in.next();
                System.out.println("enter your password");
                String password=in.next();
                for(i=0;i<3;i++)
                {
                    f=s[i].checkcreadentials(name,password);
                   
                if(f==1)
                {
                    int op;
                    do{
                        System.out.println("choose 1 for deposite\nchoose 2 for withdraw\nchoose 3 for checkbalance\nchoose 4 for  exit:");
                         op=in.nextInt();
                        switch (op) {
                            case 1:
                                System.out.println("enter amount to deposit\n ");
                                double amount=in.nextDouble();
                                s[i].deposit(amount);
                                break;
                            case 2:
                                System.out.println("enter amount to withdraw\n");
                                 amount=in.nextDouble();
                                 s[i].withdraw(amount);
                                 break;
                            case 3:
                                s[i].checkbalance();
                                break;
                            case 4:
                                System.out.println("thankyou");
                                s[i].exit();
                                break;

                        
                            default:
                                break;
                        }
                    }while(op!=5);
                    
                }
            }
            if(f==0)
            {
                System.out.println("enter correct your name and password\n");
                break;
            }
                
            }
        }while(k!=0);
        System.out.println("visit again");
    }
}