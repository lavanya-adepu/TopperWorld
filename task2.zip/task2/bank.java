package bank1;
public interface bank {

    public void deposit(double amount);
    public void withdraw(double amount);
    public void checkbalance();
    public void exit();
    public int checkcreadentials(String name,String pass);

}