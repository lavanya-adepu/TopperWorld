import java.util.*;
public class numberguessing{
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);    
        Random random=new Random();
        int numtoguess=random.nextInt(100)+1;
        int guess=0;
        System.out.println("\nwelcome to the number guessing game");
        System.out.println("I have selected a number from 1-100 can you guess the number");
        System.out.println("you have only 5 chances to guess the number");
        int t=0;
        int f=0;
        while(t<5)
        {
            System.out.println("enter your number");
            guess=in.nextInt();
            if(guess==numtoguess)
            {
                System.out.println("your guess is correct and the number is "+guess+"\n");
                f=1;
                break;
            }
            else if(guess<numtoguess)
            {
                System.out.println("your guess is small to my number\n");
            }
            else if(guess>numtoguess)
            {
                System.out.println("your guess is large to my number\n");
            }
            t++;
        }
        if(f==0)
        {
            System.out.println("your chances completed\n");
        }

    }
}